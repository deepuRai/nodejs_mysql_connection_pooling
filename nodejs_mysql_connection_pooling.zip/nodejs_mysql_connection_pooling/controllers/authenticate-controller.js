var User=require('../models/user');

module.exports.authenticate=function(req,res){
//User.authenticateUser;

User.authenticateUser(req.body,res,function(err,rows){  
  
  try{
     
    res.json(rows);
}
  catch(err)
  {             
     res.json(err);
  }
  
 
});


}